typedef struct 
{
SDL_Rect camera;
}scr;

void scrolling(scr * s ,SDL_Surface* screen,SDL_Surface* backg,int placeperso,SDL_Rect backgrect);
void initscrol(scr * s);
void initscrol2(scr * s);

