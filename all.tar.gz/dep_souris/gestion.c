#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <string.h>

#include "gestion.h"



void initgestiondeviescore(gestion * a) {
a->heart=IMG_Load("res/heart.png");
a->key=IMG_Load("res/key.png");
a->keyon=IMG_Load("res/keyon.png");
a->life1.x=400;
a->life1.y=30;
a->life1.w=50;
a->life1.h=50;
a->life2.x=450;
a->life2.y=30;
a->life2.w=50;
a->life2.h=50;
a->life3.x=500;
a->life3.y=30;
a->life3.w=50;
a->life3.h=50;
a->key1.x=400;
a->key1.y=80;
a->key1.w=50;
a->key1.h=50;
a->key2.x=450;
a->key2.y=80;
a->key2.w=50;
a->key2.h=50;
a->key3.x=500;
a->key3.y=80;
a->key3.w=50;
a->key3.h=50;
}

void initgestiondeviescore2(gestion * a) {
a->heart=IMG_Load("res/heart.png");
a->key=IMG_Load("res/key.png");
a->keyon=IMG_Load("res/keyon.png");
a->life1.x=900;
a->life1.y=30;
a->life1.w=50;
a->life1.h=50;
a->life2.x=950;
a->life2.y=30;
a->life2.w=50;
a->life2.h=50;
a->life3.x=1000;
a->life3.y=30;
a->life3.w=50;
a->life3.h=50;
a->key1.x=900;
a->key1.y=80;
a->key1.w=50;
a->key1.h=50;
a->key2.x=950;
a->key2.y=80;
a->key2.w=50;
a->key2.h=50;
a->key3.x=1000;
a->key3.y=80;
a->key3.w=50;
a->key3.h=50;
}






void gestiondevieetscore(gestion * a , int vie , int keys ,SDL_Surface* screen){
switch(vie){

case 1:
SDL_BlitSurface(a->heart,NULL,screen,&a->life1);
break;
case 2:
SDL_BlitSurface(a->heart,NULL,screen,&a->life1);
SDL_BlitSurface(a->heart,NULL,screen,&a->life2);
break;
case 3:
SDL_BlitSurface(a->heart,NULL,screen,&a->life1);
SDL_BlitSurface(a->heart,NULL,screen,&a->life2);
SDL_BlitSurface(a->heart,NULL,screen,&a->life3);
break;

}
switch(keys){
case 3:
SDL_BlitSurface(a->keyon,NULL,screen,&a->key1);
SDL_BlitSurface(a->keyon,NULL,screen,&a->key2);
SDL_BlitSurface(a->keyon,NULL,screen,&a->key3);
break;
case 2:
SDL_BlitSurface(a->keyon,NULL,screen,&a->key1);
SDL_BlitSurface(a->keyon,NULL,screen,&a->key2);
SDL_BlitSurface(a->key,NULL,screen,&a->key3);
break;
case 1:
SDL_BlitSurface(a->keyon,NULL,screen,&a->key1);
SDL_BlitSurface(a->key,NULL,screen,&a->key2);
SDL_BlitSurface(a->key,NULL,screen,&a->key3);
break;
case 0:
SDL_BlitSurface(a->key,NULL,screen,&a->key1);
SDL_BlitSurface(a->key,NULL,screen,&a->key2);
SDL_BlitSurface(a->key,NULL,screen,&a->key3);
break;

}
}


void freesurfacesdegestion(gestion *a){
SDL_FreeSurface(a->heart);
SDL_FreeSurface(a->key);
SDL_FreeSurface(a->keyon);
}


