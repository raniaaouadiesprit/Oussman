#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "perso.h"

int dep_souris(perso *p ,SDL_Event ev)
{
switch(ev.type)
{

case SDL_MOUSEBUTTONUP:
 {
switch (ev.key.keysym.sym)
 {
   case SDL_BUTTON_RIGHT:

while(event.button.x>p->position.x)
{
   p->position.x+=10;
}
while(event.button.x<p->position.x)
{
   p->position.x-=10;
}
    break;}
}
}
}

