#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include <string.h>
#include "gestiontemp.h"



void init_temp(temp * a) {
a->timing.x=900;
a->timing.y=150;
a->timing.w=50;
a->timing.h=50;
}







void gestion_temp(temp * a ,SDL_Surface* screen){
char tt[64]="25";
int t;
int minute = 0;
int seconde = 0;
t=SDL_GetTicks();
minute = (a->timeTemps / 1000) / 60;
seconde = (a->timeTemps / 1000) % 60;
sprintf(tt, "TEMPS : %d:%d", minute, seconde);
	TTF_Init();
a->fonttexte=TTF_OpenFont("res/o.ttf",30);
	SDL_Color couleurtexte = {0,0,0};
a->chrono=TTF_RenderText_Solid(a->fonttexte,tt,couleurtexte);
	SDL_BlitSurface(a->chrono, NULL,screen,&a->timing); 
SDL_FreeSurface(a->chrono);
TTF_CloseFont(a->fonttexte);
	TTF_Quit();
}



