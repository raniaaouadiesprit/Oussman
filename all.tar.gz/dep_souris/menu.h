typedef struct 
{
int mode;
int dif;
SDL_Rect menurect;
SDL_Surface * menu;

}menu;
void init_menu(menu  *save );
void afficher_menu(SDL_Surface *screen,menu * mm);

