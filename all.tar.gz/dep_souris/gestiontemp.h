typedef struct 
{
SDL_Rect timing;
TTF_Font *fonttexte;
SDL_Surface *chrono;
SDL_Color couleurtexte , couleur ;
int timeTemps;
}temp;


void init_temp(temp * a) ;
void gestion_temp(temp * a ,SDL_Surface* screen);

