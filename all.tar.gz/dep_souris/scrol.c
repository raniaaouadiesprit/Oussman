#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "scrol.h"
void scrolling(scr * s ,SDL_Surface* screen,SDL_Surface* backg,int placeperso,SDL_Rect backgrect){


s->camera.x=placeperso;
if(s->camera.x>=6600){
SDL_Delay(200);
s->camera.x=0;
}
SDL_BlitSurface(backg,&s->camera,screen,&backgrect);
}

void initscrol(scr * s){
s->camera.x=0;
s->camera.y=0;
s->camera.w=1100;
s->camera.h=400;

}
void initscrol2(scr * s){
s->camera.x=550;
s->camera.y=0;
s->camera.w=550;
s->camera.h=400;

}



