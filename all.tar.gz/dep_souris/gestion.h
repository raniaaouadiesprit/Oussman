typedef struct 
{
SDL_Rect life1;
SDL_Surface* heart;
SDL_Rect life2;
SDL_Rect life3;
SDL_Rect key1;
SDL_Surface* key;
SDL_Surface* keyon;
SDL_Rect key2;
SDL_Rect key3;
}gestion;

void initgestiondeviescore2(gestion * a);
void initgestiondeviescore(gestion * a);
void gestiondevieetscore(gestion * a , int vie , int keys ,SDL_Surface* screen);
void freesurfacesdegestion(gestion *a);
