#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_ttf.h>
#include "menu.h"

void init_menu(menu  *save ){
save->menu=IMG_Load("res/menu.jpeg");
save->menurect.x=0;
save->menurect.y=0;
save->menurect.w=1100;
save->menurect.h=400;
}
void afficher_menu(SDL_Surface *screen,menu * mm)
{
int cont=1;
mm->dif=2;
while(cont){
SDL_BlitSurface(mm->menu,NULL,screen,&mm->menurect);
SDL_Event ev;
SDL_Flip(screen);
SDL_PollEvent(&ev);
switch(ev.type)
{case SDL_MOUSEBUTTONDOWN:
if( ev.button.button == SDL_BUTTON_LEFT )
		{
if(220<ev.button.y&&ev.button.y<270)
{if(40<ev.button.x&&ev.button.x<275)
{
mm->dif=1;
 
}else if(420<ev.button.x&&ev.button.x<660)
{

mm->dif=2;


}else if(800<ev.button.x&&ev.button.x<1030)
{
mm->dif=3;


}
}

if(80<ev.button.y&&ev.button.y<130)
{if(40<ev.button.x&&ev.button.x<275)
{
cont=0;
mm->mode=1;
 
}else if(420<ev.button.x&&ev.button.x<660)
{

cont=0;
mm->mode=2;

}else if(800<ev.button.x&&ev.button.x<1030)
{
cont=0;
mm->mode=3;

}



}
break;
}}
}
}

