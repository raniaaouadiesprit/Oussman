#ifndef MYWORK_H_INCLUDED
#define MYWORK_H_INCLUDED
#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>


typedef struct
{
SDL_Surface* imagemini;
SDL_Rect posmini;
SDL_Surface* imagenokta;
SDL_Rect posnokta;
}mini;



void init_positions(mini *e,int x,int y);
void init_positions1(mini *e,int x,int y);
void init_affich(mini *e,SDL_Surface* s);
void key_event (mini *e,SDL_Surface* s,int x);
void key_event1 (mini *e,SDL_Surface* s,int x);
#endif // MYWORK_H_INCLUDED

