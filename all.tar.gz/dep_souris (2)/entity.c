#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "entity.h"


void initialise_entity(entity * es,int x,int y){

es->vie=3;
es->direction=0;
es->image=IMG_Load("res/player1.1.png");
SDL_GetClipRect(es->image,&es->position);
es->position.x=x;
es->position.y=y;
}

void afficher_entity (entity * es,SDL_Surface *screen,SDL_Rect* screenrect1)
{
	
	
	SDL_BlitSurface(es->image,NULL,screen,&es->position);	    
}
void deplacement_alea_ennemi(entity *es){
    
         
           if(es->direction==0){
       
             es->position.x=es->position.x+1;
              if(es->position.x>2600){
                es->direction=1;
              }
            }
         if(es->direction==1){
           es->position.x=es->position.x-1;
         if(es->position.x<2500){

             es->direction=0;
         }
        }

}

void animationentity(entity *es ,SDL_Surface* screen){



if(es->direction==1)
{
   
  es->image=IMG_Load("res/player1.png");

}
else
if(es->direction==0)
{ 
  es->image=IMG_Load("res/player1.1.png");

}
}
/*******************************************************************************/

/*******************************************************************************/
