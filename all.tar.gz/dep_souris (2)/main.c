#include <stdio.h>
#include <stdlib.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include "perso.h"
#include "entity.h"
#include "gestion.h"
#include "scrol.h"
#include "ennemi.h"
#define LARGEUR 1100
#define HAUTEUR 400
//declaration SDL
SDL_Surface* screen=NULL;
SDL_Rect screenrect={0,0,0,0};
SDL_Surface* backg=NULL;
SDL_Surface* backg1=NULL;
SDL_Rect backgrect={0,0,550,400};
SDL_Rect backgrect1={570,0,550,400};
SDL_Surface* tmp=NULL;
SDL_Event ev;
SDL_Event ev2;

int main(int argc, char** argv)
{
    
//Declaration
perso p;
perso p2;
entity es;
scr s;
scr s2;
gestion a;
gestion a2;

Ennemi ennemi;

int keys=3;
SDL_Init(SDL_INIT_VIDEO);
const SDL_VideoInfo *pinfo=SDL_GetVideoInfo();
int bpp=pinfo->vfmt->BitsPerPixel;
int now=0;
int ex=0;
int pfps=33;
int dt=0;
int test;
int posy;
int testp=0;

int ie;
char path_ennemi [500] = "res/ennemi_spr.png";

screen=SDL_SetVideoMode(LARGEUR,HAUTEUR,bpp,SDL_HWSURFACE);
SDL_WM_SetCaption("Game",NULL);
//background
tmp=IMG_Load("res/gamebackg.png");
if(testp==0)
{
backg=SDL_DisplayFormat(tmp);
backg1=SDL_DisplayFormat(tmp);
//SDL_FreeSurface(tmp);

//SDL_GetClipRect(backg,&backgrect);
SDL_SetClipRect(backg,&backgrect);
SDL_SetClipRect(backg1,&backgrect1);
//inti

initialisePerso(&p);
initialisePerso2(&p2);

initialise_entity(&es,2500,200);

initgestiondeviescore(&a);
initgestiondeviescore2(&a2);

initscrol(&s);
initscrol(&s2);
//boucle Game.x
while(p.running)
{
now=SDL_GetTicks();
dt=now-ex;
backg=SDL_DisplayFormat(tmp);
backg1=SDL_DisplayFormat(tmp);
if(dt>=pfps)
{


//affichage
SDL_PollEvent(&ev2);
afficherPerso (&p,backg);
SDL_BlitSurface(p2.image,&p2.frame,backg1,&p2.position);
afficherPerso (&p2,backg1);
afficher_entity(&es,backg,&backgrect);

scrolling(&s,screen,backg,p.position.x,backgrect);
scrolling(&s2,screen,backg1,p2.position.x,backgrect1);

p.running=moveperso(&p ,screen,ev2);
p2.running=moveperso2(&p2 ,screen,ev2);

animationperso(&p ,screen);
animationperso(&p2 ,screen);

deplacement_alea_ennemi(&es);

gestiondevieetscore(&a,p.vie ,p.score ,screen);
gestiondevieetscore(&a2,p2.vie ,p2.score ,screen);

test=collisionBoundingBox(p.position,es.position);
dep_souris(&p ,ev,s.camera.x);
animationentity(&es ,screen);
//sautpersonnage(ev,&p);

printf("x= %d x1=%d\n",p2.position.x,p.position.x);
if(test==1)
{
p.vie--;
}


//display #ALL
SDL_Flip(screen);
SDL_FreeSurface(backg);
SDL_FreeSurface(backg1);
}
else 
 SDL_Delay(pfps-dt);
}
}
else 
if(testp==1)
{
/***************************************************************************************************************/
backg=SDL_DisplayFormat(tmp);

//SDL_FreeSurface(tmp);


SDL_GetClipRect(backg,&backgrect);

//inti
ie = init_ennemi(&ennemi, path_ennemi);
initialisePerso(&p);


initialise_entity(&es,2500,200);

initgestiondeviescore(&a);


initscrol(&s);

//boucle Game.x
while(p.running)
{
now=SDL_GetTicks();
dt=now-ex;
backg=SDL_DisplayFormat(tmp);

if(dt>=pfps)
{


//affichage
SDL_PollEvent(&ev2);
afficherPerso (&p,backg);
display_ennemi(&ennemi,backg);

afficher_entity(&es,backg,&backgrect);
p.running=moveperso(&p ,screen,ev2);
update_ennemi(&ennemi, p.position);

scrolling(&s,screen,backg,p.position.x,backgrect);







animationperso(&p ,screen);


deplacement_alea_ennemi(&es);

gestiondevieetscore(&a,p.vie ,p.score ,screen);


test=collisionBoundingBox(p.position,es.position);

dep_souris(&p ,ev,s.camera.x);
animationentity(&es ,screen);
//sautpersonnage(ev,&p);

printf("x= %d x1=%d\n",p2.position.x,p.position.x);
if(test==1)
{
p.vie--;
}


//display #ALL
SDL_Flip(screen);
SDL_FreeSurface(backg);
SDL_FreeSurface(backg1);

}
else 
 SDL_Delay(pfps-dt);
}



/***************************************************************************************************************/

}
//#FREE!!!!!!!!!!!!!!!
SDL_FreeSurface(p.image);
//freeEnnemi(&ennemi);




SDL_Quit();
return 0;
}

